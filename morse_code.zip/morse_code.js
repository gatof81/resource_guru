//map for morse code.
let code = {
	"A": ".-",
	"B": "-...",
	"C": "-.-.",
	"D": "-..",
	"E": ".",
	"F": "..-.",
	"G": "--.",
	"H": "....",
	"I": "..",
	"J": ".---",
	"K": "-.-",
	"L": ".-..",
	"M": "--",
	"N": "-.",
	"O": "---",
	"P": ".--.",
	"Q": "--.-",
	"R": ".-.",
	"S": "...",
	"T": "-",
	"U": "..-",
	"V": "...-",
	"W": ".--",
	"X": "-..-",
	"Y": "-.--",
	"Z": "--..",
	"0": "-----",
	"1": ".----",
	"2": "..---",
	"3": "...--",
	"4": "....-",
	"5": ".....",
	"6": "-....",
	"7": "--...",
	"8": "---..",
	"9": "----.",
	".": ".-.-.-",
	",": "--..--"
}
// map for slash count.
var alph = {
	1:"A",
	2:"B",
	3:"C",
	4:"D",
	5:"E",
}
/*
obfuscation could have easily been fixed but I thought it would be a good idea
to generate it on execution, this way obfuscation rules can be change on startup.
*/
let obfuscation = {};

fs = require('fs')
fs.readFile('./inputs.txt', 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
	//will generate the obfuscation map.
  obfuscationMap(data);
});

function obfuscationMap(data){
	for(let i in code){
		obfuscation[code[i]] = code[i].match(/(\.[\.]*)|(-[-]*)/g).reduce((off, val) =>
		off + (val[0]=== "-" ? alph[val.length]:val.length),'')
	}
	//after generating the obfuscation map and then send the file content to encode.
	encode(data.toUpperCase().split("\n"));
}

function encode(data){
	for (let line of data){
		//only alpahnumeric lines including space, dot and comma.
		if(line.match(/^[0-9a-zA-Z\s\,\.]+$/)){
			let resultA = "";
			let resultB = "";
			let l = line.split("");
			for(e of l){
				//only space is a unmapped valid character.
				if(e === " "){
					resultA = resultA.slice(0, -1) + "/";
					resultB = resultB.slice(0, -1) + "/";
				}else {
					resultA += code[e]+"|";
					resultB += obfuscation[code[e]]+"|";
				}
			}
			console.log(line);
			//output for morse code and obfuscation.
			console.log(resultA);
			console.log(resultB);
		}
	}
}
