let flaterned = [];
function flattern(arrs) {
  for (el of arrs) {
    if(Array.isArray(el)){
      flattern(el);
    }else{
      flaterned.push(el);
    }
  }
}

flattern([ 1, [ 2, [ 3 ] ], 4 ]);
console.log(flaterned);
