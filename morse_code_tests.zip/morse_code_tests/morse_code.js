//map for morse code.
let code = {
    "A": ".-",
    "B": "-...",
    "C": "-.-.",
    "D": "-..",
    "E": ".",
    "F": "..-.",
    "G": "--.",
    "H": "....",
    "I": "..",
    "J": ".---",
    "K": "-.-",
    "L": ".-..",
    "M": "--",
    "N": "-.",
    "O": "---",
    "P": ".--.",
    "Q": "--.-",
    "R": ".-.",
    "S": "...",
    "T": "-",
    "U": "..-",
    "V": "...-",
    "W": ".--",
    "X": "-..-",
    "Y": "-.--",
    "Z": "--..",
    "0": "-----",
    "1": ".----",
    "2": "..---",
    "3": "...--",
    "4": "....-",
    "5": ".....",
    "6": "-....",
    "7": "--...",
    "8": "---..",
    "9": "----.",
    ".": ".-.-.-",
    ",": "--..--"
}
// map for slash count.
var alph = {
    1: "A",
    2: "B",
    3: "C",
    4: "D",
    5: "E",
}
/*
obfuscation could have easily been fixed but I thought it would be a good idea
to generate it on execution, this way obfuscation rules can be change on startup.
*/
let obfuscation = {};

// fs = require('fs')
// fs.readFile(filename, 'utf8', function (err,data) {
// if (err) {
// return console.log(err);
// }
// //will generate the obfuscation map.
// obfuscationMap(data);
// });

function obfuscationMap(data) {
    for (let i in code) {
        obfuscation[code[i]] = code[i].match(/(\.[\.]*)|(-[-]*)/g).reduce((off, val) =>
            off + (val[0] === "-" ? alph[val.length] : val.length), '')
    }
    //after generating the obfuscation map and then send the file content to encode.
    return encode(data.toUpperCase().split("\n"));
}

function encode(data) {
    let ofuscatedCode = "";
		if(data[data.length - 1] === ""){
			data.pop();
		}
    for (let keys in data) {
        //only alpahnumeric lines including space, dot and comma.
        if (data[keys].match(/^[0-9a-zA-Z\s\,\.]+$/)) {
            //let morse_code = "";
            let ofuscated_code = "";
            let l = data[keys].split("");
            for (let key in l) {
                if (l[key] === " ") {
                    //morse_code = morse_code.slice(0, -1) + "/";
										if(ofuscated_code.charAt(ofuscated_code.length -1 === "|")){
											ofuscated_code = ofuscated_code.slice(0, -1);
										}
                    ofuscated_code += "/";
                } else {
                    //morse_code += code[l[key]];
                    ofuscated_code += obfuscation[code[l[key]]];
                    if (key < l.length - 1) {
                        //morse_code += "|";
                        ofuscated_code += "|";
                    }
                }
            }
            ofuscatedCode += ofuscated_code;
            if (keys < data.length - 1) {
                ofuscatedCode += "\n"
            }
        }
    }
    return ofuscatedCode;
}

module.exports = obfuscationMap;
