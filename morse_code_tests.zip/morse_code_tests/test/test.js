var assert = require('assert');
var encoder = require("../morse_code.js");
fs = require('fs');

describe('basic example', function() {
  before(function(done){
    fs.readFile('basic.txt', 'utf8', function(err, fileContents) {
          if (err) throw err;
          result = encoder(fileContents);
          done();
        });
    });

  describe('example input for basic testing', function() {
    it('should return true in basic test.', function() {
        assert.equal(result,`4|1|1A2|1A2|C\n2/1A|B/2|A1/A|1A1|C|2A|A3|1A2|1`);
    });

    it("shouldn't be empty.", function() {
        assert.notEqual(result,``);
    });
    it("should return two lines", function() {
        assert.equal(result.split("\n").length,2);
    });
    it("shouldn't end with jumpline", function() {
        assert.notEqual(result.charAt(result.length - 1),"n");
    });
    it("shouldn't end with letter spliter", function() {
        assert.notEqual(result.charAt(result.length - 1),"|");
    });
  });
});

describe('advanced example 1', function() {
  before(function(done){
    fs.readFile('UpperLowerCase.txt', 'utf8', function(err, fileContents) {
          if (err) throw err;
          result = encoder(fileContents);
          done();
        });
    });

  describe("input contain upper and lower case letter and this shouldn't affect the result", function() {
    it('should return true in basic test.', function() {
        assert.equal(result,`1B1|1A2|1A|A1A1|1/3|1|A1|A2/B|1/A1A1|C|1A1|A2|2|A1|1A|A|1|3|1A1A1A`);
    });
    it("shouldn't be empty.", function() {
        assert.notEqual(result,``);
    });
    it("should return one lines", function() {
        assert.equal(result.split("\n").length,1);
    });
    it("shouldn't end with jumpline", function() {
        assert.notEqual(result.charAt(result.length - 1),"n");
    });
    it("shouldn't end with letter spliter", function() {
        assert.notEqual(result.charAt(result.length - 1),"|");
    });
  });
});

describe('advanced example 2', function() {
  before(function(done){
    fs.readFile('invalid.txt', 'utf8', function(err, fileContents) {
          if (err) throw err;
          result = encoder(fileContents);
          done();
        });
    });

  describe("input contain invalid characters", function() {
    it('should return true if result is empty.', function() {
        assert.equal(result,``);
    });
    it("should return 0 lines", function() {
        assert.notEqual(result.split("\n").length,0);
    });
    it("shouldn't end with jumpline", function() {
        assert.notEqual(result.charAt(result.length - 1),"n");
    });
    it("shouldn't end with letter spliter", function() {
        assert.notEqual(result.charAt(result.length - 1),"|");
    });
  });
});

describe('advanced example 3', function() {
  before(function(done){
    fs.readFile('mixed.txt', 'utf8', function(err, fileContents) {
          if (err) throw err;
          result = encoder(fileContents);
          done();
        });
    });

  describe("mixed lines with valid and invalid lines.", function() {
    it('should return true if only valid lines are obfuscated.', function() {
        assert.equal(result,`1B1|1A2|1A|A1A1|1|B2B/3|1|A1|A2/B|1/A1A1|C|1A1|A2|2|A1|1A|A|1|3|1A1A1A\n2/A1|1|1|A2/A|C|1A1A1A`);
    });
    it("shouldn't be empty.", function() {
        assert.notEqual(result,``);
    });
    it("should return two lines", function() {
        assert.equal(result.split("\n").length,2);
    });
    it("shouldn't end with jumpline", function() {
        assert.notEqual(result.charAt(result.length - 1),"n");
    });
    it("shouldn't end with letter spliter", function() {
        assert.notEqual(result.charAt(result.length - 1),"|");
    });
  });
});

describe('advanced example 4', function() {
  before(function(done){
    fs.readFile('spacesAndJumpLines.txt', 'utf8', function(err, fileContents) {
          if (err) throw err;
          result = encoder(fileContents);
          done();
        });
    });

  describe("multiples spaces and line jumps.", function() {
    it('should return true if only valid lines are obfuscated.', function() {
        assert.equal(result,`1B1|1A2|1A|A1A1|1/3|1|A1|A2/B|1/A1A1|C|1A1|A2|2|A1|1A|A|1|3|1A1A1A\n1B1|1A2|1A|A1A1|1/3|1|A1|A2/B|1/A1A1|C|1A1|A2|2|A1|1A|A|1|3|1A1A1A`);
    });
    it("shouldn't be empty.", function() {
        assert.notEqual(result,``);
    });
    it("should return two lines", function() {
        assert.equal(result.split("\n").length,2);
    });
    it("shouldn't end with jumpline", function() {
        assert.notEqual(result.charAt(result.length - 1),"n");
    });
    it("shouldn't end with letter spliter", function() {
        assert.notEqual(result.charAt(result.length - 1),"|");
    });
  });
});
